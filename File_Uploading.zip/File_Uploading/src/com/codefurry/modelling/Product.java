package com.codefurry.modelling;

public class Product {
	
	

}
