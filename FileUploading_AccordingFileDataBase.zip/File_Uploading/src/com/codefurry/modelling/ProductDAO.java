package com.codefurry.modelling;

import java.util.List;

public interface ProductDAO {
	
public List<Product> getAllProducts();
	
	public Product getProduct(Product b);
	
	public void insertProduct(Product b);
	
	public void deleteProduct(Product b);
	
	public void update(Product b, Product b1);

	public Product getProduct(int product_id);

	public void updateProduct(Product oldProduct, Product updateProduct);

}
