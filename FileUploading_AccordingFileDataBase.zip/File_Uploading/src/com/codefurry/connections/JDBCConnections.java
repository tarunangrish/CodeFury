package com.codefurry.connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCConnections {
public static void main(String[] args) {
		
	try
	{
		Class.forName("org.apache.derby.jdbc.ClientDriver");
		
		Connection con = DriverManager.getConnection("jdbc:derby:codefurry;create=true");
		
		PreparedStatement st = con.prepareStatement("insert into product values(?,?,?,?,?)");
		st.setInt(1, (int)1);
		st.setString(2, "abc");
		st.setInt(3, (int)123);
		st.setInt(4, (int)2);
		st.setInt(5, (int)12);
		
		st.executeUpdate();
		st = con.prepareStatement("select * from product");
		ResultSet rs = st.executeQuery();
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+" "+rs.getNString(2)+" "+rs.getInt(3)+rs.getInt(4)+rs.getInt(5));
		}
		
		con.close();
	}
	catch(ClassNotFoundException ex)
	{
		ex.printStackTrace();
	}
	catch(SQLException ex)
	{
		ex.printStackTrace();
	}
	}
}

